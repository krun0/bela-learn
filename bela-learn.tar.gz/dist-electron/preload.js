"use strict";const e=require("electron");e.contextBridge.exposeInMainWorld("electronAPI",{platform:process.platform,isDev:process.env.NODE_ENV==="development"});console.log("Preload script loaded");
